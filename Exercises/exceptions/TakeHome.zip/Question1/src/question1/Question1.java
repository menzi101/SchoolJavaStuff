// Not too sure if I am understanding the question but I'll answer as best I could.
package question1;

/**
 * Menzi Hlope
 * CGMSXBYZ5
 */
public class Question1 {
    static final double h = 5;
    static final double r = 5;
    
    public static void main(String[] args) {
     
double vol = Math.PI * r * r * h;

System.out.println("Volume = " + vol);
    }
    
}
