-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2020 at 02:14 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `question7`
--
CREATE DATABASE IF NOT EXISTS `question7` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `question7`;

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `Title` varchar(250) NOT NULL,
  `Publisher` varchar(250) NOT NULL,
  `Year_Published` varchar(250) NOT NULL,
  `Author` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`Title`, `Publisher`, `Year_Published`, `Author`) VALUES
('Head First Java', 'OReilly', '2017', 'Griffiths'),
('MySQL', 'Addison_Wesley', '2013', 'Paul DuBois'),
('PHP and Apache', 'SAMS', '2018', 'Julie Melon'),
('ZendFramewrok', 'Manning', '2016', 'Rob Allen');
--
-- Database: `question8`
--
CREATE DATABASE IF NOT EXISTS `question8` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `question8`;

-- --------------------------------------------------------

--
-- Table structure for table `salesstaff`
--

CREATE TABLE `salesstaff` (
  `empID` int(250) NOT NULL,
  `empName` varchar(250) NOT NULL,
  `empSurname` varchar(250) NOT NULL,
  `empTel` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `salesstaff`
--

INSERT INTO `salesstaff` (`empID`, `empName`, `empSurname`, `empTel`) VALUES
(1, 'HHH', 'HH', 'BB'),
(2, 'This', 'is', '12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `salesstaff`
--
ALTER TABLE `salesstaff`
  ADD PRIMARY KEY (`empID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `salesstaff`
--
ALTER TABLE `salesstaff`
  MODIFY `empID` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Database: `question9`
--
CREATE DATABASE IF NOT EXISTS `question9` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `question9`;

-- --------------------------------------------------------

--
-- Table structure for table `studentdetails`
--

CREATE TABLE `studentdetails` (
  `stNumber` text NOT NULL,
  `stName` text NOT NULL,
  `stSurname` text NOT NULL,
  `stLevel` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `studentdetails`
--

INSERT INTO `studentdetails` (`stNumber`, `stName`, `stSurname`, `stLevel`) VALUES
('Free', 'Kioo', 'Kioo', 'Level 1'),
('Help', 'pl', 'pl', 'comboBoxChanged'),
('hh', 'dd', 'dd', 'Certificate'),
('john', 'Wworld', 'Wworld', 'Level 2'),
('one', 'time', 'time', 'Certificate'),
('Onetwr', 'Time', 'Time', 'Level 3'),
('we', 'one', 'one', 'javax.swing.JComboBox[,193,97,193x32,layout=javax.swing.plaf.metal.MetalComboBoxUI$MetalComboBoxLayoutManager,alignmentX=0.0,alignmentY=0.0,border=,flags=328,maximumSize=,minimumSize=,preferredSize=,isEditable=false,lightWeightPopupEnabled=true,maximumRowCount=8,selectedItemReminder=Level 1]');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `studentdetails`
--
ALTER TABLE `studentdetails`
  ADD PRIMARY KEY (`stNumber`(250));
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
