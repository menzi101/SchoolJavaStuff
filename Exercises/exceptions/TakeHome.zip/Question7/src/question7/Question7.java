package question7;

/**
 * Menzi Hlope
 * CGMSXBYZ5
 */
public class Question7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
